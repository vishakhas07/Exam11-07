/* Program to print even and odd using command line argument

  */


#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>
#include<iostream>




